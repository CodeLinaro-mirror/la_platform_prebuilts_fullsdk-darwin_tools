<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1493337494647'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/Volumes/Android/buildbot/src/googleplex-android/studio-2.3-release/out/host/maven/bundles-25.2.2-SNAPSHOT/products/monitorproduct/macosx/cocoa/x86_64/monitor'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=macosx,osgi.arch=x86_64,osgi.ws=cocoa,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/Volumes/Android/buildbot/src/googleplex-android/studio-2.3-release/out/host/maven/bundles-25.2.2-SNAPSHOT/products/monitorproduct/macosx/cocoa/x86_64/monitor'/>
  </properties>
</profile>
