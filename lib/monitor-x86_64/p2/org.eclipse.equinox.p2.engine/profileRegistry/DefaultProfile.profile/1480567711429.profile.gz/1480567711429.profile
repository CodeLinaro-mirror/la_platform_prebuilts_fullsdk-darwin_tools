<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1480567711429'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.installFolder' value='/Volumes/Android/buildbot/src/android/emu-2.2-release/out/host/maven/bundles-25.2.4-SNAPSHOT/products/monitorproduct/macosx/cocoa/x86_64/monitor'/>
    <property name='org.eclipse.equinox.p2.cache' value='/Volumes/Android/buildbot/src/android/emu-2.2-release/out/host/maven/bundles-25.2.4-SNAPSHOT/products/monitorproduct/macosx/cocoa/x86_64/monitor'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.nl=en_US,osgi.ws=cocoa,osgi.arch=x86_64,osgi.os=macosx'/>
  </properties>
</profile>
